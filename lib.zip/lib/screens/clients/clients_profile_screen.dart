// lib/screens/clients/client_profile_screen.dart
//
// Commit 5 — v2 (fixes de overflow + rediseño según fotos)
//
// Cambios vs v1:
//  1. Stats box → 3 pills (sin No-show para caber sin overflow)
//     + last visit debajo. Header height auto.
//  2. Action pills eliminadas del header zone.
//     Bottom bar fijo: [🗑 borrar] [📅 new appt] [✏ edit]
//  3. Booking request "+" pill verde + pill edit dentro de la card
//     → llama a _editRequestSheet (showModalBottomSheet igual que home)
//  4. Upcoming/Past tabs son el contenido principal, sin card rara encima.
//  5. "+ Booking req" pill verde dentro del tab Upcoming, junto al toggle.

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:salon_app/components/ui/app_gradient_header.dart';
import 'package:salon_app/components/ui/app_icon_pill_button.dart';
import 'package:salon_app/components/ui/app_section_card.dart';
import 'package:salon_app/generated/l10n.dart';
import 'package:salon_app/provider/admin_nav_provider.dart';
import 'package:salon_app/repositories/booking_request_repo.dart';
import 'package:salon_app/utils/app_time_picker.dart';
import 'package:salon_app/utils/booking_request_utils.dart';
import 'package:salon_app/utils/date_time_utils.dart';
import 'package:salon_app/utils/time_of_day_utils.dart';
import 'package:salon_app/widgets/async_optimistic_switch.dart';
import 'package:salon_app/widgets/booking_request_card.dart';
import 'package:salon_app/widgets/booking_request_create_form.dart';

class ClientProfileScreen extends StatefulWidget {
  const ClientProfileScreen({super.key, required this.clientId});
  final String clientId;

  @override
  State<ClientProfileScreen> createState() => _ClientProfileScreenState();
}

class _ClientProfileScreenState extends State<ClientProfileScreen>
    with SingleTickerProviderStateMixin {
  static const Color kPurple = Color(0xff721c80);
  static const Color kGreen  = Color(0xff2e7d32);

  late final TabController _tabController;
  late final BookingRequestRepo _brRepo;

  Map<String, dynamic> _clientData = {};
  bool _loading = true;
  bool _looking = false;

  // Edit controllers
  final _fnCtrl      = TextEditingController();
  final _lnCtrl      = TextEditingController();
  final _countryCtrl = TextEditingController();
  final _phoneCtrl   = TextEditingController();
  final _igCtrl      = TextEditingController();

  // Booking request creation state
  String? _brWorkerId;
  String? _brServiceId;
  Map<String, dynamic>? _brServiceData;
  int _brDurationMin = 30;
  final List<String>         _brDayKeys = [];
  final List<Map<String, int>> _brRanges = [];

  static const int _bizStart = 7 * 60;
  static const int _bizEnd   = 21 * 60;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _brRepo = BookingRequestRepo(FirebaseFirestore.instance);
    _loadClient();
  }

  @override
  void dispose() {
    _tabController.dispose();
    _fnCtrl.dispose(); _lnCtrl.dispose(); _countryCtrl.dispose();
    _phoneCtrl.dispose(); _igCtrl.dispose();
    super.dispose();
  }

  // ── Data ─────────────────────────────────────────────────────────────────────

  Future<void> _loadClient() async {
    final snap = await FirebaseFirestore.instance
        .collection('clients').doc(widget.clientId).get();
    _clientData = snap.data() ?? {};
    _fnCtrl.text      = (_clientData['firstName'] ?? '').toString();
    _lnCtrl.text      = (_clientData['lastName']  ?? '').toString();
    _countryCtrl.text = (_clientData['country']   ?? '').toString();
    _phoneCtrl.text   = (_clientData['phone']     ?? '').toString();
    _igCtrl.text      = (_clientData['instagram'] ?? '').toString();
    _looking = _clientData['bookingRequestActive'] == true;
    if (mounted) setState(() => _loading = false);
  }

  String _fullName() {
    final v = '${(_clientData['firstName'] ?? '').toString().trim()} '
              '${(_clientData['lastName']  ?? '').toString().trim()}'.trim();
    return v.isEmpty ? S.of(context).clientFallback : v;
  }

  String _contactLine() {
    final c  = _num('country'); final p = _num('phone');
    final ig = (_clientData['instagram'] ?? '').toString().trim();
    final parts = <String>[];
    if (c > 0 && p > 0) parts.add('+$c $p');
    if (ig.isNotEmpty) parts.add('@$ig');
    return parts.join(' • ');
  }

  int _num(String k) {
    final v = _clientData[k];
    if (v is num) return v.toInt();
    return int.tryParse('$v') ?? 0;
  }

  Map<String, dynamic> get _stats =>
      (_clientData['stats'] as Map?)?.cast<String, dynamic>() ?? {};

  // ── Streams ───────────────────────────────────────────────────────────────────

  Stream<QuerySnapshot<Map<String, dynamic>>> _upcomingStream() =>
      FirebaseFirestore.instance
          .collection('appointments')
          .where('clientId', isEqualTo: widget.clientId)
          .where('status', isEqualTo: 'scheduled')
          .where('appointmentDate', isGreaterThanOrEqualTo: Timestamp.now())
          .orderBy('appointmentDate')
          .limit(50)
          .snapshots();

  Stream<QuerySnapshot<Map<String, dynamic>>> _pastStream() =>
      FirebaseFirestore.instance
          .collection('appointments')
          .where('clientId', isEqualTo: widget.clientId)
          .where('appointmentDate', isLessThan: Timestamp.now())
          .orderBy('appointmentDate', descending: true)
          .limit(100)
          .snapshots();

  // ── Range helpers ─────────────────────────────────────────────────────────────

  bool _rangesFitDuration(List<Map<String, int>> ranges, int dur) {
    if (ranges.isEmpty) return true;
    for (final r in ranges) {
      if ((r['endMin'] ?? 0) - (r['startMin'] ?? 0) < dur) return false;
    }
    return true;
  }

  Future<void> _addBrDay() async {
    final now   = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final picked = await showDatePicker(
      context: context,
      firstDate: today, lastDate: DateTime(now.year + 2), initialDate: today,
    );
    if (picked == null) return;
    final key = BookingRequestUtils.yyyymmdd(picked);
    setState(() {
      if (!_brDayKeys.contains(key)) _brDayKeys.add(key);
      _brDayKeys.sort();
    });
  }

  Future<void> _addBrRange() async {
    final start = await AppTimePicker.pick5m(
        context: context, initial: const TimeOfDay(hour: 9, minute: 0));
    if (start == null) return;
    final fs = TimeOfDayUtils.clamp(start,
        minMinutes: _bizStart, maxMinutes: _bizEnd - 15);
    final minEnd = TimeOfDayUtils.toMinutes(fs);
    final end = await AppTimePicker.pick5m(
        context: context,
        initial: TimeOfDayUtils.fromMinutes(minEnd + 15));
    if (end == null) return;
    var fe = TimeOfDayUtils.clamp(end,
        minMinutes: _bizStart + 15, maxMinutes: _bizEnd);
    if (TimeOfDayUtils.isBefore(fe, fs)) fe = fs;
    setState(() => _brRanges.add(BookingRequestUtils.range(fs, fe)));
  }

  // ── Booking request actions ───────────────────────────────────────────────────

  Future<void> _confirmAndDisableLooking() async {
    final docs = await _brRepo.getActiveRequestsForClient(widget.clientId);
    if (!mounted) return;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Disable booking requests?'),
        content: Text(docs.isEmpty
            ? "Disable 'Looking for appointment'. Continue?"
            : 'Delete all ${docs.length} active requests and disable? Continue?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancel')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Confirm', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok != true) return;
    if (docs.isNotEmpty) await _brRepo.deleteAllActiveForClient(widget.clientId);
    await FirebaseFirestore.instance.collection('clients')
        .doc(widget.clientId).set({
      'bookingRequestActive': false,
      'bookingRequestUpdatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    if (!mounted) return;
    setState(() => _looking = false);
  }

  Future<void> _createRequest() async {
    if (_brServiceId == null) {
      ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Select a procedure first')));
      return;
    }
    _brServiceData ??= (await FirebaseFirestore.instance
        .collection('services').doc(_brServiceId!).get()).data();
    final svc     = _brServiceData ?? {};
    final nameKey = (svc['name'] ?? '').toString();
    final label   = nameKey.isNotEmpty ? nameKey : _brServiceId!;
    final dur     = svc['durationMin'] is num
        ? (svc['durationMin'] as num).toInt() : 30;

    await _brRepo.upsertRequest(
      workerId: _brWorkerId,
      clientId: widget.clientId,
      serviceId: _brServiceId!,
      serviceNameKey: nameKey,
      serviceNameLabel: label,
      durationMin: dur,
      exactSlots: const [],
      preferredDays: List.from(_brDayKeys),
      preferredTimeRanges: List.from(_brRanges),
    );
    await FirebaseFirestore.instance.collection('clients')
        .doc(widget.clientId).set({
      'bookingRequestActive': true,
      'bookingRequestUpdatedAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
    if (!mounted) return;
    setState(() {
      _looking = true;
      _brDayKeys.clear(); _brRanges.clear();
      _brWorkerId = null; _brServiceId = null; _brServiceData = null;
      _brDurationMin = 30;
    });
    Navigator.pop(context);
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Booking request created')));
  }

  // ── Bottom sheets ─────────────────────────────────────────────────────────────

  /// Edit client — showModalBottomSheet
  Future<void> _openEditSheet() async {
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (ctx) {
        final inset = MediaQuery.of(ctx).viewInsets.bottom;
        return Padding(
          padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + inset),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Edit client',
                    style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                const SizedBox(height: 14),
                TextField(controller: _fnCtrl,
                    decoration: const InputDecoration(labelText: 'First name',
                        border: OutlineInputBorder())),
                const SizedBox(height: 10),
                TextField(controller: _lnCtrl,
                    decoration: const InputDecoration(labelText: 'Last name',
                        border: OutlineInputBorder())),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(flex: 2, child: TextField(
                      controller: _countryCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Country code',
                          border: OutlineInputBorder()))),
                  const SizedBox(width: 10),
                  Expanded(flex: 4, child: TextField(
                      controller: _phoneCtrl,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'Phone',
                          border: OutlineInputBorder()))),
                ]),
                const SizedBox(height: 10),
                TextField(controller: _igCtrl,
                    decoration: const InputDecoration(labelText: 'Instagram',
                        border: OutlineInputBorder())),
                const SizedBox(height: 16),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: kPurple,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                      padding: const EdgeInsets.symmetric(vertical: 12),
                    ),
                    onPressed: () async {
                      await FirebaseFirestore.instance
                          .collection('clients').doc(widget.clientId).set({
                        'firstName': _fnCtrl.text.trim(),
                        'lastName':  _lnCtrl.text.trim(),
                        'country':   int.tryParse(_countryCtrl.text.trim()) ?? 0,
                        'phone':     int.tryParse(_phoneCtrl.text.trim()) ?? 0,
                        'instagram': _igCtrl.text.trim(),
                        'updatedAt': FieldValue.serverTimestamp(),
                      }, SetOptions(merge: true));
                      if (!ctx.mounted) return;
                      Navigator.pop(ctx);
                      ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Client updated')));
                      await _loadClient();
                    },
                    icon: const Icon(Icons.save_outlined, color: Colors.white),
                    label: const Text('Save client',
                        style: TextStyle(color: Colors.white,
                            fontWeight: FontWeight.w900)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  /// New booking request — showModalBottomSheet
  Future<void> _openBookingRequestSheet() async {
    setState(() {
      _brDayKeys.clear(); _brRanges.clear();
      _brWorkerId = null; _brServiceId = null;
      _brServiceData = null; _brDurationMin = 30;
    });

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (ctx) {
        final inset = MediaQuery.of(ctx).viewInsets.bottom;
        return StatefulBuilder(
          builder: (ctx, setLocal) => Padding(
            padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + inset),
            child: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('New booking request',
                      style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                  const SizedBox(height: 14),
                  BookingRequestCreateForm(
                    selectedWorkerId: _brWorkerId,
                    onWorkerChanged: (v) => setLocal(() => _brWorkerId = v),
                    selectedServiceId: _brServiceId,
                    onServiceChanged: (sid) async {
                      if (sid == null || sid.isEmpty) {
                        setLocal(() {
                          _brServiceId = null; _brServiceData = null;
                          _brDurationMin = 30;
                        });
                        return;
                      }
                      final doc = await FirebaseFirestore.instance
                          .collection('services').doc(sid).get();
                      final data = doc.data() ?? {};
                      final dur = data['durationMin'] is num
                          ? (data['durationMin'] as num).toInt() : 30;
                      setLocal(() {
                        _brServiceId   = sid;
                        _brServiceData = data;
                        _brDurationMin = dur;
                      });
                    },
                    selectedDays: _brDayKeys,
                    selectedRanges: _brRanges,
                    onAddDay: () async { await _addBrDay(); setLocal(() {}); },
                    onRemoveDayKey: (k) => setLocal(() => _brDayKeys.remove(k)),
                    onAddRange: () async { await _addBrRange(); setLocal(() {}); },
                    onRemoveRangeAt: (i) {
                      if (i < 0 || i >= _brRanges.length) return;
                      setLocal(() => _brRanges.removeAt(i));
                    },
                    onCreate: _createRequest,
                    purple: kPurple,
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Edit existing booking request — showModalBottomSheet
  /// Misma lógica que home_client_bottom_sheet._editRequestSheet
  Future<void> _editRequestSheet({
    required String requestId,
    required Map<String, dynamic> br,
  }) async {
    String? workerId = (br['workerId'] as String?)?.trim();
    if (workerId != null && workerId.isEmpty) workerId = null;

    String? serviceId = (br['serviceId'] as String?)?.trim();
    if (serviceId != null && serviceId.isEmpty) serviceId = null;

    final dayKeys = (br['preferredDays'] as List?)
            ?.map((e) => e.toString())
            .where((e) => e.trim().isNotEmpty)
            .toList() ?? <String>[];

    final rangeList = <Map<String, int>>[];
    for (final rr in (br['preferredTimeRanges'] as List?) ?? const []) {
      if (rr is! Map) continue;
      final m  = Map<String, dynamic>.from(rr);
      final s  = (m['startMin'] ?? m['start']);
      final e  = (m['endMin']   ?? m['end']);
      final sm = (s is num) ? s.toInt() : int.tryParse('$s') ?? -1;
      final em = (e is num) ? e.toInt() : int.tryParse('$e') ?? -1;
      if (sm >= 0 && em > sm) rangeList.add({'startMin': sm, 'endMin': em});
    }

    bool saving = false;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(18))),
      builder: (ctx) {
        final inset = MediaQuery.of(ctx).viewInsets.bottom;
        return StatefulBuilder(
          builder: (ctx, setLocal) {
            Future<void> save() async {
              if (saving) return;
              if (serviceId == null || serviceId!.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Select a procedure first')));
                return;
              }
              setLocal(() => saving = true);
              try {
                final svcDoc = await FirebaseFirestore.instance
                    .collection('services').doc(serviceId!).get();
                final svc     = svcDoc.data() ?? {};
                final nameKey = (svc['name'] ?? '').toString();
                final label   = nameKey.isNotEmpty ? nameKey : serviceId!;
                final dur     = svc['durationMin'] is num
                    ? (svc['durationMin'] as num).toInt() : 30;

                if (!_rangesFitDuration(List<Map<String, int>>.from(rangeList), dur)) {
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                      content: Text(
                          'Selected time range must be at least $dur min')));
                  return;
                }

                await _brRepo.updateRequest(
                  requestId: requestId,
                  workerId: workerId,
                  serviceId: serviceId!,
                  serviceNameKey: nameKey,
                  serviceNameLabel: label,
                  durationMin: dur,
                  preferredDays: List<String>.from(dayKeys),
                  preferredTimeRanges: List<Map<String, int>>.from(rangeList),
                );
                if (!mounted) return;
                Navigator.pop(ctx);
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Request updated')));
              } finally {
                if (ctx.mounted) setLocal(() => saving = false);
              }
            }

            return Padding(
              padding: EdgeInsets.fromLTRB(16, 8, 16, 16 + inset),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text('Edit request',
                              style: TextStyle(fontWeight: FontWeight.w900,
                                  fontSize: 16)),
                        ),
                        IconButton(
                          onPressed: saving ? null : () => Navigator.pop(ctx),
                          icon: const Icon(Icons.close),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    BookingRequestCreateForm(
                      selectedWorkerId: workerId,
                      onWorkerChanged: (v) => setLocal(() => workerId = v),
                      selectedServiceId: serviceId,
                      onServiceChanged: (newSid) async {
                        if (newSid == null || newSid.isEmpty) {
                          setLocal(() => serviceId = null);
                          return;
                        }
                        setLocal(() => serviceId = newSid);
                      },
                      selectedDays: dayKeys,
                      selectedRanges: rangeList,
                      onAddDay: () async {
                        final now   = DateTime.now();
                        final today = DateTime(now.year, now.month, now.day);
                        final picked = await showDatePicker(
                          context: ctx,
                          firstDate: today,
                          lastDate: DateTime(now.year + 2),
                          initialDate: today,
                        );
                        if (picked == null) return;
                        final key = BookingRequestUtils.yyyymmdd(picked);
                        setLocal(() {
                          if (!dayKeys.contains(key)) dayKeys.add(key);
                          dayKeys.sort();
                        });
                      },
                      onRemoveDayKey: (k) => setLocal(() => dayKeys.remove(k)),
                      onAddRange: () async {
                        final start = await AppTimePicker.pick5m(
                            context: ctx,
                            initial: const TimeOfDay(hour: 9, minute: 0));
                        if (start == null) return;
                        final sMin = start.hour * 60 + start.minute;
                        final end = await AppTimePicker.pick5m(
                            context: ctx,
                            initial: TimeOfDay(
                                hour: (sMin ~/ 60).clamp(0, 23),
                                minute: sMin % 60));
                        if (end == null) return;
                        final eMin = end.hour * 60 + end.minute;
                        if (eMin <= sMin) return;
                        setLocal(() => rangeList
                            .add({'startMin': sMin, 'endMin': eMin}));
                      },
                      onRemoveRangeAt: (i) {
                        if (i < 0 || i >= rangeList.length) return;
                        setLocal(() => rangeList.removeAt(i));
                      },
                      onCreate: save,
                      purple: kPurple,
                    ),
                    if (saving)
                      const Padding(
                        padding: EdgeInsets.only(top: 8),
                        child: CircularProgressIndicator(),
                      ),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ── Appointment card ──────────────────────────────────────────────────────────

  Widget _apptCard(Map<String, dynamic> d) {
    final ts      = d['appointmentDate'];
    final date    = ts is Timestamp ? ts.toDate() : null;
    final dateStr = date != null
        ? DateTimeUtils.formatYyyyMmDdToDdMmYyyy(DateTimeUtils.yyyymmdd(date))
        : (d['date'] ?? '').toString();
    final timeStr    = date != null
        ? DateTimeUtils.hhmmFromMinutes(date.hour * 60 + date.minute) : '';
    final service    = (d['serviceName'] ?? d['service'] ?? '').toString();
    final status     = (d['status'] ?? '').toString();
    final workerName = (d['workerName'] ?? d['workerId'] ?? '').toString();

    final statusColor = {
      'scheduled': kPurple,
      'done':      Colors.green,
      'cancelled': Colors.red,
      'noShow':    Colors.orange,
    }[status] ?? Colors.grey;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.withOpacity(0.05),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.black12),
      ),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(service.isNotEmpty ? service : '—',
                    style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 3),
                Text('$dateStr${timeStr.isNotEmpty ? "  ·  $timeStr" : ""}',
                    style: TextStyle(color: Colors.grey[700], fontSize: 13)),
                if (workerName.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(workerName,
                      style: TextStyle(color: Colors.grey[500], fontSize: 12)),
                ],
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: statusColor.withOpacity(0.12),
              borderRadius: BorderRadius.circular(999),
            ),
            child: Text(status,
                style: TextStyle(color: statusColor,
                    fontWeight: FontWeight.w700, fontSize: 12)),
          ),
        ],
      ),
    );
  }

  // ── Stats box (dentro del header) ─────────────────────────────────────────────

  Widget _statsBox() {
    final s           = _stats;
    final requested   = (s['totalAppointments'] as num?)?.toInt() ?? 0;
    final attended    = (s['totalScheduled']    as num?)?.toInt() ?? 0;
    final cancelled   = (s['totalCancelled']    as num?)?.toInt() ?? 0;
    final noShow      = (s['totalNoShow']        as num?)?.toInt() ?? 0;
    final lastTs      = s['lastAppointmentAt']  as Timestamp?;
    final lastSummary = (s['lastAppointmentSummary'] ?? '').toString();

    return Container(
      margin: const EdgeInsets.only(top: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.15),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 4 pills en una fila con Wrap para evitar overflow
          Wrap(
            spacing: 6,
            runSpacing: 4,
            children: [
              _sPill('Requested: $requested'),
              _sPill('Attended: $attended',  bg: Colors.green.withOpacity(0.4)),
              _sPill('Cancelled: $cancelled', bg: Colors.orange.withOpacity(0.4)),
              _sPill('No-show: $noShow',      bg: Colors.red.withOpacity(0.4)),
            ],
          ),
          if (lastTs != null) ...[
            const SizedBox(height: 6),
            Text(
              'Last attended appointment',
              style: TextStyle(
                  color: Colors.white.withOpacity(0.8),
                  fontSize: 11,
                  fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 2),
            Text(
              () {
                final d = lastTs.toDate();
                final date = DateTimeUtils.formatYyyyMmDdToDdMmYyyy(
                    DateTimeUtils.yyyymmdd(d));
                final time = DateTimeUtils.hhmmFromMinutes(
                    d.hour * 60 + d.minute);
                return '$date  ·  $time${lastSummary.isNotEmpty ? "  ·  $lastSummary" : ""}';
              }(),
              style: const TextStyle(
                  color: Colors.white, fontSize: 11,
                  fontWeight: FontWeight.w600),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ],
      ),
    );
  }

  Widget _sPill(String label,
      {Color bg = const Color(0x33FFFFFF)}) =>
      Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(999),
        ),
        child: Text(label,
            style: const TextStyle(
                color: Colors.white, fontSize: 11,
                fontWeight: FontWeight.w800)),
      );

  // ── Upcoming tab ──────────────────────────────────────────────────────────────

  Widget _buildUpcomingTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Booking request toggle + "+ Booking req" pill ──────────────
          AppSectionCard(
            title: 'Booking request',
            trailing: AppIconPillButton(
              icon: Icons.add,
              color: kGreen,
              size: 32,
              iconSize: 16,
              tooltip: 'New booking request',
              onTap: _openBookingRequestSheet,
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    _looking ? 'Looking for appointment' : 'Not looking',
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                ),
                AsyncOptimisticSwitch(
                  value: _looking,
                  switchActiveColor: kPurple,
                  onSave: (v) async {
                    if (!v) { await _confirmAndDisableLooking(); return; }
                    setState(() => _looking = true);
                    await FirebaseFirestore.instance
                        .collection('clients').doc(widget.clientId).set({
                      'bookingRequestActive': true,
                      'bookingRequestUpdatedAt': FieldValue.serverTimestamp(),
                    }, SetOptions(merge: true));
                  },
                ),
              ],
            ),
          ),

          // ── Active booking requests ──────────────────────────────────
          const SizedBox(height: 12),
          StreamBuilder<List<QueryDocumentSnapshot<Map<String, dynamic>>>>(
            stream: _brRepo.streamActiveRequestsForClient(widget.clientId),
            builder: (_, snap) {
              final docs = snap.data ?? [];
              if (docs.isEmpty) return const SizedBox.shrink();
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Active booking requests',
                      style: TextStyle(
                          fontWeight: FontWeight.w900, fontSize: 14)),
                  const SizedBox(height: 8),
                  ...docs.map((d) => Padding(
                    padding: const EdgeInsets.only(bottom: 10),
                    child: BookingRequestCard(
                      requestId: d.id,
                      br: d.data(),
                      purple: kPurple,
                      onDelete: () async {
                        final ok = await showDialog<bool>(
                          context: context,
                          builder: (dctx) => AlertDialog(
                            title: const Text('Delete request?'),
                            actions: [
                              TextButton(
                                  onPressed: () => Navigator.pop(dctx, false),
                                  child: const Text('No')),
                              ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.red),
                                onPressed: () => Navigator.pop(dctx, true),
                                child: const Text('Delete',
                                    style: TextStyle(color: Colors.white)),
                              ),
                            ],
                          ),
                        );
                        if (ok != true) return;
                        await _brRepo.deleteRequest(d.id);
                      },
                      // ← Abre el bottom sheet de edición
                      onEditRequest: () => _editRequestSheet(
                          requestId: d.id, br: d.data()),
                    ),
                  )),
                ],
              );
            },
          ),

          // ── Upcoming appointments ────────────────────────────────────
          const SizedBox(height: 16),
          const Text('Upcoming appointments',
              style: TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
          const SizedBox(height: 10),
          StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
            stream: _upcomingStream(),
            builder: (_, snap) {
              if (snap.connectionState == ConnectionState.waiting) {
                return const Center(
                    child: CircularProgressIndicator(color: kPurple));
              }
              if (snap.hasError) {
                return Text('Error: ${snap.error}',
                    style: const TextStyle(color: Colors.red));
              }
              final docs = snap.data?.docs ?? [];
              if (docs.isEmpty) {
                return Text('No upcoming appointments.',
                    style: TextStyle(color: Colors.grey[700]));
              }
              return Column(
                  children: docs.map((d) => _apptCard(d.data())).toList());
            },
          ),
        ],
      ),
    );
  }

  // ── Past tab ──────────────────────────────────────────────────────────────────

  Widget _buildPastTab() {
    return StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
      stream: _pastStream(),
      builder: (_, snap) {
        if (snap.connectionState == ConnectionState.waiting) {
          return const Center(
              child: CircularProgressIndicator(color: kPurple));
        }
        if (snap.hasError) {
          return Center(child: Text('Error: ${snap.error}',
              style: const TextStyle(color: Colors.red)));
        }
        final docs = snap.data?.docs ?? [];
        if (docs.isEmpty) {
          return Center(child: Text('No past appointments.',
              style: TextStyle(color: Colors.grey[700])));
        }
        return ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
          itemCount: docs.length,
          itemBuilder: (_, i) => _apptCard(docs[i].data()),
        );
      },
    );
  }

  // ── Bottom bar fijo ───────────────────────────────────────────────────────────
  // [✏ edit cliente izq] [📅 new appt centro] [🗑 borrar der]

  Widget _bottomBar() {
    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(color: Colors.black.withOpacity(0.08),
                blurRadius: 10, offset: const Offset(0, -2)),
          ],
        ),
        child: Row(
          children: [
            // Edit client (izquierda)
            AppIconPillButton(
              icon: Icons.edit_outlined,
              color: Colors.grey[700]!,
              size: 44,
              tooltip: 'Edit client',
              onTap: _openEditSheet,
            ),
            const Spacer(),
            // New appointment (centro, más grande y morado)
            Expanded(
              flex: 3,
              child: ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: kPurple,
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(14)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onPressed: () {
                  context.read<AdminNavProvider>()
                      .goToBookingWithClient(widget.clientId);
                  Navigator.pop(context);
                },
                icon: const Icon(Icons.edit_calendar_outlined,
                    color: Colors.white, size: 18),
                label: const Text('New appointment',
                    style: TextStyle(color: Colors.white,
                        fontWeight: FontWeight.w900)),
              ),
            ),
            const Spacer(),
            // Delete (derecha)
            AppIconPillButton(
              icon: Icons.delete_outline,
              color: Colors.red,
              size: 44,
              tooltip: 'Delete client',
              onTap: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (dctx) => AlertDialog(
                    title: const Text('Delete client?'),
                    content: const Text(
                        'This will delete the client document. Continue?'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(dctx, false),
                          child: const Text('No')),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red),
                        onPressed: () => Navigator.pop(dctx, true),
                        child: const Text('Delete',
                            style: TextStyle(color: Colors.white)),
                      ),
                    ],
                  ),
                );
                if (ok != true) return;
                await FirebaseFirestore.instance
                    .collection('clients').doc(widget.clientId).delete();
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('Client deleted')));
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  // ── Build ─────────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
          body: Center(child: CircularProgressIndicator(color: kPurple)));
    }

    final name    = _fullName();
    final contact = _contactLine();

    return Scaffold(
      body: Column(
        children: [
          // Header morado: nombre + contacto + stats box
          AppGradientHeader(
            title: name,
            subtitle: contact.isNotEmpty ? contact : null,
            height: 200,
            child: _statsBox(),
          ),

          // Tabs
          Material(
            color: Colors.white,
            child: TabBar(
              controller: _tabController,
              labelColor: kPurple,
              unselectedLabelColor: Colors.grey,
              indicatorColor: kPurple,
              tabs: const [Tab(text: 'Upcoming'), Tab(text: 'Past')],
            ),
          ),

          // Contenido tabs
          Expanded(
            child: TabBarView(
              controller: _tabController,
              children: [_buildUpcomingTab(), _buildPastTab()],
            ),
          ),

          // Bottom bar fijo
          _bottomBar(),
        ],
      ),
    );
  }
}
